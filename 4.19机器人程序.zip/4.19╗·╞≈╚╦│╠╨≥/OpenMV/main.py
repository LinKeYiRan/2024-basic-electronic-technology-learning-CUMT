from pyb import Timer,UART,LED
import pyb,ustruct,math,sensor,image
color = 0
red_led   = pyb.LED(1)
green_led = pyb.LED(2)
blue_led  = pyb.LED(3)
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False)
sensor.set_auto_whitebal(False)
uart = pyb.UART(3, 115200, timeout_char = 1000)
def write(data):
    uart.write(data)
def available():
    return uart.any()
def read_byte():
    return uart.readchar()
def uart_send():
    global color
    data = ustruct.pack("<bbb",
    0x2C,
    color,
    0x5B)
    write(data)
red = [(20, 52, 27, 113, 4, 53),(20, 52, 27, 113, 4, 53),(20, 52, 27, 113, 4, 53)]
yellow = [(82, 98, -41, -17, 60, 82),(80, 90, -53, -17, 63, 85),(20, 52, 27, 113, 4, 53)]
blue = [(21, 52, -20, 25, -58, -17),(20, 52, 27, 113, 4, 53),(20, 52, 27, 113, 4, 53)]
while (True):
    img = sensor.snapshot().lens_corr(1.8)
    for r in img.find_rects(threshold = 10000):#小于threshold的过滤   rect矩形
        img.draw_rectangle(r.rect(), color = (255, 0, 0))
        area = (r.x(),r.y(),r.w(),r.h())
        statistics = img.get_statistics(roi=area)
        for i in range(3):
            if red[i][0]<statistics.l_mode()<red[i][1] and red[i][2]<statistics.a_mode()<red[i][3] and red[i][4]<statistics.b_mode()<red[i][5]:
                img.draw_rectangle(area, color = (255, 0, 0))
                print(color)
                color = 1
                red_led.on()
                green_led.off()
                blue_led.off()
            elif yellow[i][0]<statistics.l_mode()<yellow[i][1] and yellow[i][2]<statistics.a_mode()<yellow[i][3] and yellow[i][4]<statistics.b_mode()<yellow[i][5]:
                img.draw_rectangle(area, color = (0, 255, 255))
                print(color)
                color = 2
                red_led.off()
                green_led.on()
                blue_led.on()
            elif blue[i][0]<statistics.l_mode()<blue[i][1] and blue[i][2]<statistics.a_mode()<blue[i][3] and blue[i][4]<statistics.b_mode()<blue[i][5]:
                img.draw_rectangle(area, color = (0, 0, 255))
                print(color)
                color = 3
                red_led.off()
                green_led.off()
                blue_led.on()
            else:
                img.draw_rectangle(area, color = (0, 0, 0))
    uart_send()
