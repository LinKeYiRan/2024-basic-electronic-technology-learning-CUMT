from pyb import Timer,UART,LED
import pyb,ustruct,math,sensor,image

color = 0   #Color Type

# LED Setup

red_led   = pyb.LED(1)
green_led = pyb.LED(2)
blue_led  = pyb.LED(3)

# Camera Setup
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking

# Uart Setup P4:TX,P5:RX
uart = pyb.UART(3, 115200, timeout_char = 1000)

def write(data):
    uart.write(data)

def available():
    return uart.any()

def read_byte():
    return uart.readchar()

# Timer Setup
def uart_send():
    global color
    data = ustruct.pack("<bbb",
    0x2C,                      #帧头1
    color,
    0x5B)   #帧尾
    write(data)

#tim = Timer(4, freq=20)
#tim.callback(uart_send)

#黄底红色(18, 51, 18, 76, 100, 17)  (30, 60, -98, 77, 22, 122)
#蓝底黄色(76, 96, -31, -12, 49, 90)
#红底蓝色(32, 19, 12, -8, -62, -17)
red = [20, 52, 27, 113, 4, 53]
yellow = [82, 98, -41, -17, 60, 82]
blue = [21, 52, -20, 25, -58, -17]
# Main Loop
while (True):
    img = sensor.snapshot().lens_corr(1.8)
    for r in img.find_rects(threshold = 10000):
        img.draw_rectangle(r.rect(), color = (255, 0, 0))
        area = (r.x(),r.y(),r.w(),r.h())#矩形区域
        statistics = img.get_statistics(roi=area)#像素颜色统计
        if red[0]<statistics.l_mode()<red[1] and red[2]<statistics.a_mode()<red[3] and red[4]<statistics.b_mode()<red[5]:
            img.draw_rectangle(area, color = (255, 0, 0))#识别到的红色矩形用红色的矩形框出来
            print(color)
            color = 1
            red_led.on()
            green_led.off()
            blue_led.off()
        elif yellow[0]<statistics.l_mode()<yellow[1] and yellow[2]<statistics.a_mode()<yellow[3] and yellow[4]<statistics.b_mode()<yellow[5]:
            img.draw_rectangle(area, color = (0, 255, 255))#识别到的黄色矩形用黄色的矩形框出来
            print(color)
            color = 2
            red_led.off()
            green_led.on()
            blue_led.off()
        elif blue[0]<statistics.l_mode()<blue[1] and blue[2]<statistics.a_mode()<blue[3] and blue[4]<statistics.b_mode()<blue[5]:
            img.draw_rectangle(area, color = (0, 0, 255))#识别到的蓝色矩形用蓝色的矩形框出来
            print(color)
            color = 3
            red_led.off()
            green_led.off()
            blue_led.on()
        else:
            img.draw_rectangle(area, color = (0, 0, 0))
            #将非红色的矩形用黑色的矩形框出来
    uart_send()
    #color = 0






