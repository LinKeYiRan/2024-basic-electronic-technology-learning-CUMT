from pyb import Timer,UART,LED
import pyb,ustruct,math,sensor,image

send = 0    #Send Flag
color = 0   #Color Type

# LED Setup

red_led   = pyb.LED(1)
green_led = pyb.LED(2)
blue_led  = pyb.LED(3)

# Camera Setup
sensor.reset()
sensor.set_pixformat(sensor.RGB565)
sensor.set_framesize(sensor.QQVGA)
sensor.skip_frames(time = 2000)
sensor.set_auto_gain(False) # must be turned off for color tracking
sensor.set_auto_whitebal(False) # must be turned off for color tracking

# Uart Setup P4:TX,P5:RX
uart = pyb.UART(3, 115200, timeout_char = 1000)

def write(data):
    uart.write(data)

def available():
    return uart.any()

def read_byte():
    return uart.readchar()

def uart_send():
    global color
    data = ustruct.pack("<bbbb",
    0x2C,                      #帧头1
    0x12,                      #帧头2
    color,
    0x5B)   #帧尾
    write(data)

# Timer Setup
def uart_read(timer):
    global send
    if available():
        buffer_1 = read_byte()
        if buffer_1 == 0x55:
            buffer_2 = read_byte()
            if buffer_2 == 0xAA:
                send = 1
    if send == 1:
        uart_send()
        send = 0
        red_led.on()

tim = Timer(4, freq=200)
tim.callback(uart_read)

#黄底红色(18, 51, 18, 76, 100, 17)  (30, 60, -98, 77, 22, 122)
#蓝底黄色(76, 96, -31, -12, 49, 90)
#红底蓝色(32, 19, 12, -8, -62, -17)

# Main Loop
while (True):
    img = sensor.snapshot().lens_corr(1.8)
    for r in img.find_rects(threshold = 10000):
        img.draw_rectangle(r.rect(), color = (255, 0, 0))
        area = (r.x(),r.y(),r.w(),r.h())#矩形区域
        statistics = img.get_statistics(roi=area)#像素颜色统计
        if 30<statistics.l_mode()<60 and -98<statistics.a_mode()<77 and 22<statistics.b_mode()<122:
            img.draw_rectangle(area, color = (255, 0, 0))#识别到的红色矩形用红色的矩形框出来
            print("red")
        elif 76<statistics.l_mode()<96 and -31<statistics.a_mode()<-12 and 49<statistics.b_mode()<90:
            img.draw_rectangle(area, color = (0, 255, 255))#识别到的黄色矩形用黄色的矩形框出来
            print("yellow")
        elif 19<statistics.l_mode()<32 and -8<statistics.a_mode()<12 and -62<statistics.b_mode()<-17:
            img.draw_rectangle(area, color = (0, 0, 255))#识别到的蓝色矩形用蓝色的矩形框出来
            print("blue")
        else:
            img.draw_rectangle(area, color = (0, 0, 0))
            #将非红色的矩形用黑色的矩形框出来








