#include "z_timer.h"
#include "z_gpio.h"
#include "stm32f10x_conf.h"
#include "z_global.h"
#include "z_usart.h"
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "z_delay.h"
#include "z_sensor.h"
#include "z_servo.h"
#include "Z_main.h"
#include "z_delay.h"		//存放延时函数
// systick register
#define SYSTICK_TENMS    (*((volatile unsigned long *)0xE000E01C))  
#define SYSTICK_CURRENT  (*((volatile unsigned long *)0xE000E018))  
#define SYSTICK_RELOAD   (*((volatile unsigned long *)0xE000E014))  
#define SYSTICK_CSR       (*((volatile unsigned long *)0xE000E010)) 

u32 systick_ms = 0;

u8 ir_start=0,ir_start_flag=0;
u8 ir_repeat=0,ir_repeat_flag=0;
u8 ir_end_flag=0,ir_time_flag=0;
u8 ir_data_count=0;
int speed=500;

float piancha=0.0;	
float piancha1=0.0;
float error=0,Integral_error,Last_error;
float error1=0,Integral_error1,Last_error1;
int kp=60,ki=0,kd=45;
int kp1=60,ki1=0,kd1=40;
int qian=0,zuo=0,you=0,hou=0;
int youcha=0,zuocha=0;
int youT=0,zuoT=0;
int shangT=0,xiaT=0;
int shizi=0;
int jishi=0;
int zuzhi=1;//防止标志位瞬时累加多次
int youxia=0,youshang=0,zuoshang=0,zuoxia=0;
int qingchu=0;//用于延时来使zuzhi为1
int hong=0,lan=0,huang=0;
//初始化函数
int na=13;//用于标记拾取物体和放置物体
int ding=0,dingtime=0;
int buchang=0;
int b=0;
u8  yanshi=0;
int fan=0,fan1=0;
float _abs(float temp) {
	if(temp>0)return temp;
	else {
		return (-temp);
	}
}

void SysTick_Int_Init(void) {
	SYSTICK_CURRENT = 0;
	SYSTICK_RELOAD = 72000;
	SYSTICK_CSR|=0x07;
}
void SysTick_Handler(void) {   
	SYSTICK_CURRENT=0;  
	systick_ms++;
}

u32 millis(void) {
	return systick_ms;
}

void TIM1_Int_Init(u16 arr,u16 psc) {
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
	NVIC_InitTypeDef NVIC_InitStructure;  

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE); //时钟使能  

	TIM_TimeBaseStructure.TIM_Period = arr; //设置自动重装载寄存器周期值  
	TIM_TimeBaseStructure.TIM_Prescaler =(psc-1);//设置预分频值  
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; //设置时钟分割  
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;//向上计数模式  
	TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;//重复计数设置  
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure); //参数初始化  
	TIM_ClearFlag(TIM1, TIM_FLAG_Update);//清中断标志位  

	TIM_ITConfig(      //使能或者失能指定的TIM中断  
	TIM1,            //TIM1  
	TIM_IT_Update  | //TIM 更新中断源  
	TIM_IT_Trigger,  //TIM 触发中断源   
	ENABLE           //使能  
	);  
	  
	//设置优先级  
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;    
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;//先占优先级0级  
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;       //从优先级0级  
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   

	TIM_Cmd(TIM1, ENABLE);  //使能TIMx外设 
}


/***********************************************
	函数名称：	TIM2_init() 
	功能介绍：	初始化TIM2
	函数参数：	无
	返回值：		无
 ***********************************************/
void TIM2_init(void) {
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE); 				//①时钟 TIM2 使能	
	//定时器 TIM2 初始化
	TIM_TimeBaseStructure.TIM_Period = 19999; 										//设置自动重装载寄存器周期的值
	TIM_TimeBaseStructure.TIM_Prescaler = 71; 									//设置时钟频率除数的预分频值
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 		//设置时钟分割
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //TIM 向上计数
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);  						//②初始化 TIM2
	TIM_ARRPreloadConfig(TIM2, DISABLE);
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE );  									//③允许更新中断
	
	//中断优先级 NVIC 设置
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;  						//TIM2 中断
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; 	//先占优先级 1 级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  				//从优先级 1 级
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  						//IRQ 通道被使能
	NVIC_Init(&NVIC_InitStructure);  														//④初始化 NVIC 寄存器
	TIM_Cmd(TIM2, ENABLE);  																		//⑤使能 TIM2
}

 void TIM3_Int_Init(u16 arr,u16 psc) {
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE); //①时钟 TIM3 使能	
	//定时器 TIM3 初始化
	TIM_TimeBaseStructure.TIM_Period = arr; //设置自动重装载寄存器周期的值
	TIM_TimeBaseStructure.TIM_Prescaler = psc; //设置时钟频率除数的预分频值
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; //设置时钟分割
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //TIM 向上计数
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);  //②初始化 TIM3
	TIM_ARRPreloadConfig(TIM3, DISABLE);
	TIM_ITConfig(TIM3,TIM_IT_Update,ENABLE );  //③允许更新中断
	
	//中断优先级 NVIC 设置
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;  //TIM3 中断
	//NVIC_SetVectorTable(NVIC_VectTab_FLASH,0x0000);
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1; //先占优先级 1 级
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 2;  //从优先级 2 级
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  //IRQ 通道被使能
	NVIC_Init(&NVIC_InitStructure);  //④初始化 NVIC 寄存器
	TIM_Cmd(TIM3, ENABLE);  //⑤使能 TIM3
}
//串⼝2（PA3/RXD2，PA2/TXD2）
void TIM3_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET) //检查 TIM3 更新中断发生与否
	{
		TIM_ClearITPendingBit(TIM3 , TIM_IT_Update);
		if(zuzhi==0&&qingchu<30)
		{
			qingchu ++;
		}
		if(zuzhi==0&&qingchu>=30)
		{
			qingchu = 0;
			zuzhi =1;			
		}
		if(shizi==1)beep_on();
		if(shizi==2)beep_off();
		if(shizi==3){beep_on();}
		if(shizi==4){beep_off();}
		if(shizi ==5)beep_on();


		if(ding==0)
		{
			MotorCtrl();
			lukuangudge();
		}
	ding_yellow_object_in_yellow_area();
	ding_blue_object_in_blue_area();
	ding_red_object_in_red_area();
	//首先，先让车前进，然后会遇到第一个上T字，此时让车直走即可，然后遇到第一个十字，让车直走，此时会遇到第一个
	//右岔路，让车停车，抓取物体，后退，遇到第二个十字，右移动；遇到第二个十字，后退，，遇到第二个右岔路，停车，放东西。
	}
}
void flag_clear(void)
{
	shizi=0;
	youxia=0;
	zuoshang=0;
	xiaT=0;
	zuoT=0;
	youshang=0;
	youT=0;
}
void lukuangudge(void)
{
		//正方形的四个边，分别为有右上、右下、左上、左下
 //右下
if((huidu[1]==1||huidu[2]==1)&&(huidu[5]==1||huidu[6]==1||huidu[4]==1||huidu[7]==1)
  &&(huidu[9]==0&&huidu[10]==0)&&(huidu[13]==0&&huidu[14]==0))
 {
 if(zuzhi==1)
  {
   youxia+=1;
   zuzhi =0;
  }
 }
 //左上
if((huidu[9]==1||huidu[10]==1)&&(huidu[14]==1||huidu[13]==1)
  &&(huidu[0]==0&&huidu[3]==0&&huidu[1]==0&&huidu[2]==0)&&(huidu[4]==0&&huidu[5]==0&&huidu[6]==0&&huidu[7]==0))
 {
  if(zuzhi==1)
  {
   zuoshang+=1;
   zuzhi =0;
  }
 }
 //左下
if((huidu[1]==1||huidu[2]==1)&&(huidu[9]==1||huidu[10]==1)
  &&(huidu[5]==0&&huidu[6]==0)&&(huidu[13]==0&&huidu[14]==0))
 {
  if(zuzhi==1)
  {
   zuoxia+=1;
   zuzhi =0;
  }
 }
 //右上
if((huidu[4]==1||huidu[7]==1||huidu[5]==1||huidu[6]==1)&&(huidu[12]==1||huidu[15]==1||huidu[13]==1||huidu[14]==1)
  &&(huidu[1]==0&&huidu[2]==0&&huidu[0]==0&&huidu[3]==0)&&(huidu[9]==0&&huidu[10]==0&&huidu[8]==0&&huidu[11]==0))
 {
  if(zuzhi==1)
  {
   youshang+=1;
   zuzhi =0;
  }
 }
 	//下T路，下面、左面、右面中间两个传感器都为1
	if((huidu[0]==0&&huidu[1]==0&&huidu[2]==0&&huidu[3]==0)&&(huidu[5]==1||huidu[6]==1)&&
		(huidu[9]==1||huidu[10]==1)&&(huidu[13]==1||huidu[14]==1))
	{
		if(zuzhi==1)
		{
			xiaT+=1;
			zuzhi=0;
		}
	}
 
	//右T路，左面的传感器全为0且右面中间两个和前面中间两个是0
	if((huidu[4]==0&&huidu[5]==0&&huidu[6]==0&&huidu[7]==0)&&
		 (huidu[9]==1||huidu[10]==1)&&
		 (huidu[0]==1||huidu[1]==1||huidu[2]==1||huidu[3]==1)&&
		 (huidu[12]==1||huidu[13]==1||huidu[14]==1||huidu[15]==1)
		)
	{
		if(zuzhi==1)
		{
			youT+=1;
			zuzhi =0;
		}
	}
	//左T路，右面的传感器全为0且左面中间两个和前面中间两个为0
	if((huidu[8]==0&&huidu[9]==0&&huidu[10]==0&&huidu[11]==0)&&
		(huidu[7]==1||huidu[5]==1)
	&&(huidu[1]==1||huidu[2]==1)&&
		(huidu[13]==1||huidu[14]==1))
	{
		if(zuzhi ==1)
		{
			zuoT+=1;
			zuzhi=0;
		}
	}
//	//上T路，上面、左右面中间两个传感器都为1；
//	if((huidu[1]==1||huidu[2]==1)&&(huidu[5]==1||huidu[6]==1)&&(huidu[9]==1||huidu[10]==1)&&huidu[13]==0&&huidu[14]==0)
//	{
//		if(zuzhi==1)
//		{
//			shangT+=1;
//			zuzhi=0;
//		}
//	}

	
	//十字判断，前后左右各有两个传感器为1
	if((huidu[8]==1||huidu[9]==1||huidu[10]==1||huidu[11]==1)&&(huidu[4]==1||huidu[5]==1||huidu[6]==1||huidu[7]==1)
		&&(huidu[0]==1||huidu[1]==1||huidu[2]==1||huidu[3]==1)&&(huidu[12]==1||huidu[13]==1||huidu[14]==1||huidu[15]==1))
	{
		if(zuzhi==1)
		{
			shizi+=1;
			zuzhi =0;
		}
	}
}
void ding_yellow_object_in_yellow_area(void)
{
		if(ding==1)//第一次拿快递(黄色区域)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		   //	actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding =0;
				na=1;//第一次拿快递（黄色区域）
				jishi =0;
			}
		}
		if(ding==2)//第一次放快递(黄色区域)
		{
			jishi++;
			if(jishi<11)
			{
				qian=1;
				MotorCtrl();	
			}
			if(jishi>11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		//		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;//电机受控
				na=2;//第一次放快递（黄色区域）
				jishi =0;
			}
			shizi=0;
			youT=0;
		}
		if(ding==3)//第二次拿快递(黄色区域)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=3;//第二次拿快递（黄色区域）
				jishi =0;		
			}
			shizi=0;
		}
		if(ding==4)//第二次放快递(黄色区域)
		{
			jishi++;
			if(jishi<11)
			{
				qian=1;
				MotorCtrl();	
			}
			if(jishi>11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		//		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;//电机受控
				na=4;
				jishi =0;
			}
			shizi = 0;
			youT = 0;
		}
		if(ding==5)//第三次拿快递(黄色区域)
		{
			jishi++;
			if(jishi<11)
			{
				zuo=1;
				MotorCtrl();	
			}
			if(jishi>11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		//		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;//电机受控
				na=5;//第三次拿快递（黄色区域）
				jishi =0;
			}	
			shizi = 0;
			youT = 0;
		}
		if(ding==6)//第三次放快递(黄色区域)
		{
			jishi++;
			if(jishi <11)
			{
				qian=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		   //	actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding =0;
				na=6;//第一次拿快递（黄色区域）
				jishi =0;
			}		
			shizi = 0;
			youT = 0;
		}
}

void ding_blue_object_in_blue_area(void)
{
		if(ding==99)//第一次拿快递(蓝色区域)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		  //	actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding =0;
				na=7;
				jishi =0;
				flag_clear();
			}
		}
		if(ding==7)//第一次拿快递(蓝色区域)
		{
			jishi++;
			if(jishi <11)
			{
				you=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		  //	actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding =0;
				na=8;
				jishi =0;
				flag_clear();
			}	
		}
		if(ding==8)//第一次放快递(蓝色区域)
		{
			jishi++;
			if(jishi<11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi>11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		//		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;//电机受控
				na=9;//第一次放快递（蓝色区域）
				jishi =0;
				flag_clear();
			}
		}
		if(ding==9)//第二次拿快递(蓝色区域)
		{
			jishi++;
			if(jishi <11)
			{
				you=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=10;//第二次拿快递（蓝色区域）
				jishi =0;
				flag_clear();
			}
		}
		if(ding==10)//第二次拿快递(蓝色区域)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=11;//第二次拿快递（蓝色区域）
				jishi =0;
				flag_clear();				
			}
		}
		if(ding==11)//第二次拿快递(蓝色区域)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=12;//第二次拿快递（蓝色区域）
				jishi =0;	
				flag_clear();				
			}
		}
}


void ding_red_object_in_red_area(void)
{
	if(ding==12)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		   //	actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding =0;
				na=13;
				jishi =0;
				flag_clear();
			}
		}
		if(ding==13)
		{
			jishi++;
			if(jishi<11)
			{
				qian=1;
				MotorCtrl();
			}
			if(jishi>21&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		//		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;//电机受控
				na=14;
				jishi =0;
				flag_clear();
			}
		}
		if(ding==14)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=15;
				jishi =0;
				flag_clear();
			}
		}
		if(ding==15)
		{
			jishi++;
			if(jishi <11)
			{
				qian=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=16;
				jishi =0;
				flag_clear();				
			}
		}
		if(ding==16)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=17;
				jishi =0;	
				flag_clear();				
			}
		}
			if(ding==17)
		{
			jishi++;
			if(jishi <11)
			{
				qian=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=18;
				jishi =0;	
				flag_clear();				
			}
		}
			if(ding==18)
		{
			jishi++;
			if(jishi <11)
			{
				hou=1;
				MotorCtrl();	
			}
			if(jishi >=11&&jishi<150)
			{
				car_set(0,0,0,0);
			//	begin_servointerrupt();
		 //		actiongroup_near();
			}
			if(jishi>150)
			{
				//end_servointerrupt();
				ding=0;
				na=19;
				jishi =0;	
				flag_clear();				
			}
		}
		
		
}












void na_yellow_object_in_yellow_area(void)
{
	if(na==1)//到放置区
	{
    if(shizi==1)
		{
			hou=1;
			ding=0;
		}
		if(shizi==2)
		{	
			qian=0;
			hou=0;
			zuo=0;
			you =1;
		}
		if(shizi==3)
		{
			qian=0;
			you=0;
			hou=1;
			youT =0;
		}
		if(shizi==4)
		{			
			//qian=0;
      hou=0;
			zuo=0;
			you =0;
			car_set(0,0,0,0);
			ding=2;		//第一次放快递(黄色区域)
		}
	}
	if(na==2)//回储存区
	{
		if(youT==0)
		{
			shizi=0;
			qian=1;
			hou=0;
			zuo=0;
			you=0;
		}
		if(youT==1)
		{
			qian=1;
			hou=0;
			zuo=0;
			you =0;
		}
		if(shizi==1)//on
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
    if(shizi==2)//off
		{
			qian=1;
			hou=0;
			zuo=0;
			you=0;
		}
		if(youT==2)
		{
			qian=0;
			//hou=0;
			zuo=0;
			you =0;
			car_set(0,0,0,0);
			ding=3;//第二次拿快递(黄色区域)
		}
	}
	if(na==3)//到放置区
	{
		if(shizi==0)
		{
			hou =1;
		}
		if(shizi==1)
		{	
			qian=0;
			hou=0;
			zuo=0;
			you=1;
		}
		if(shizi==2)
		{
			qian=0;
			hou=1;
			you=0;	
			youT=0;
		}
		if(shizi==3)
		{			
			//qian=0;
			hou=0;
			zuo=0;
			you=0;
			car_set(0,0,0,0);
			ding=4;		//第二次放快递(黄色区域)
		}
	}
	if(na==4)//回储存区
	{
		if(youT==0)
		{
			shizi=0;
			qian=1;
			hou=0;
			zuo=0;
			you=0;
		}
		if(youT==1)
		{
			qian=1;
			hou=0;
			zuo=0;
			you =0;
		}
		if(shizi==1&&youT==1)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
    if(shizi==2)
		{
			qian=1;
			hou=0;
			zuo=0;
			you=0;
		}
		if(youT==2)
		{
			qian=0;
			hou=0;
			zuo=0;
			you=1;
		}
		if((huidu[0]==1&&huidu[1]==1&&huidu[2]==1&&huidu[3]==1)
			&&(huidu[12]==0&&huidu[13]==0&&huidu[14]==0&&huidu[15]==0)
			&&(huidu[5]==1||huidu[6]==1)
			&&(huidu[9]==1||huidu[10]==1)
			)
		{
			qian=0;
			hou=0;
			//zuo=0;
			you=0;
			shizi=0;
			youT=0;
			car_set(0,0,0,0);
			ding=5;//第三次拿快递(黄蓝交界区域)
		}
	}
	if(na==5)//到放置区
	{
		if(youT==0)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
			shizi=0;
		}
		if(youT==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you =0;
		}
		if(shizi==1)
		{
			qian=0;
			hou=0;
			zuo=0;
			you=1;
		}
    if(shizi==2)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==3)
		{
			//qian=0;
			hou=0;
			zuo=0;
			you =0;
			car_set(0,0,0,0);
			ding=6;//第三次放快递(黄色区域)
		}
	}
	if(na==6)//到蓝色储存区
	{
		if(youT==0)
		{
			qian=1;
			hou=0;
			zuo=0;
			you=0;
			shizi=0;
		}
		if((huidu[0]==1&&huidu[1]==1&&huidu[2]==1&&huidu[3]==1)&&
			 (shizi==1)
			)
		{
			qian=0;
			hou=0;
			zuo=0;
			you =0;
			car_set(0,0,0,0);
			ding=99;
		}
	}
}
void na_blue_object_in_blue_area(void)
{
	if(na==7)//到放置区（蓝色）
	{
		yanshi++;
		if(yanshi<20) shizi=0;
		if(yanshi>30) yanshi=30;
		if(youT==0)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==1)
		{ 
			qian=0;
			hou=0;
			zuo=0;
			you=1;	
		}
		if(shizi==2)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==1)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
			piancha=piancha-400;
			piancha1=piancha1+300;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==2)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(shizi==3)
		{
			zuo=0;
			car_set(0,0,0,0);
			ding=7;
		}
	}
	if(na==8)//回存储区（蓝色）
	{
		if(youT==0)
		{
			qian=0;
			hou =0;
			zuo=0;
			you=1;
		}
		if(youxia==1)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
			shizi =0;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou =0;
			zuo=0;
			you=1;
		}
		if(youxia==2)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
		}
		if(shizi==1&&youxia==2)
		{
			qian=0;
			hou =0;
			zuo=1;
			you =0;
		}
		if(shizi==2&&youxia==2)
		{
			qian=1;
			hou=0;
			zuo=0;
			you =0;
		}
		if((huidu[0]==1&&huidu[1]==1&&huidu[2]==1&&huidu[3]==1)&&
			(shizi==2))
		{
			qian=0;
			car_set(0,0,0,0);
			ding=8;
		}
	}
	if(na==9)//到放置区（蓝色）
	{
		if(youT==0)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==1)
		{ 
			qian=0;
			hou=0;
			zuo=0;
			you=1;	
		}
		if(shizi==2)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==1)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
			piancha=piancha-400;
			piancha1=piancha1+300;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==2)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(shizi==3)
		{
			zuo=0;
			car_set(0,0,0,0);
			ding=9;
		}
	}
	if(na==10)//回存储区（蓝色）
	{
		if(youT==0)
		{
			qian=0;
			hou =0;
			zuo=0;
			you=1;
		}
		if(youxia==1)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
			shizi =0;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou =0;
			zuo=0;
			you=1;
		}
		if(youxia==2)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
		}
		if(shizi==1&&youxia==2)
		{
			qian=0;
			hou =0;
			zuo=1;
			you =0;
		}
		if(shizi==2&&youxia==2)
		{
			qian=1;
			hou=0;
			zuo=0;
			you =0;
		}
		if((huidu[0]==1&&huidu[1]==1&&huidu[2]==1&&huidu[3]==1)&&
			(shizi==2))
		{
			qian=0;
			car_set(0,0,0,0);
			ding=10;
		}
	}
	if(na==11)//到放置区（蓝色）
	{
		if(youT==0)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==1)
		{ 
			qian=0;
			hou=0;
			zuo=0;
			you=1;	
		}
		if(shizi==2)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==1)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
			piancha=piancha-400;
			piancha1=piancha1+300;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==2)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(shizi==3)
		{
			zuo=0;
			car_set(0,0,0,0);
			ding=11;
		}
	}
	if(na==12)//回存储区（红色）
	{
		if(youT==0)
		{
			qian=0;
			hou =0;
			zuo=0;
			you=1;
		}
		if(youxia==1)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
			shizi =0;
			zuoT=0;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou =0;
			zuo=0;
			you=1;
		}
		if(youxia==2)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
		}
		if(shizi==1&&youxia==2)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
		}
		if(zuoT==1)
		{
			qian=0;
			car_set(0,0,0,0);
			ding=12;
		}
	}
}
void na_red_object_in_red_area(void)
{
	if(na==13)//到放置区（红色）
	{
		if(shizi==0)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==1)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==1)
		{
			
			qian=0;
			hou=0;
			zuo=1;
			you=0;
	
			buchang=1;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
			buchang=0;
		}
		if(youxia==2)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(xiaT==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==2)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}

		if(shizi==3)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(shizi==4)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youT==1)
		{
			hou=0;
			ding=13;
			car_set(0,0,0,0);
		}
	}
	if(na==14)//回存储区（红色）
	{
		if(shizi==0)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(youT==1)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(shizi==1)
		{
			zuo=1;
			hou=0;
			qian =0;
			you=0;
		}
		if(zuoxia ==1)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
	//		buchang=1;
		}
		if(zuoshang==1)
		{
			you=1;
			hou=0;
			zuo =0;
			qian=0;
			buchang=1;
		}
		if(shizi==2)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
			buchang=0;
			fan1=0;
		}
		if(xiaT==1)
		{
			qian=0;
			hou=0;
			zuo =0;
			you=1;
		}
		if(youxia==1)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
			zuoT=0;
		}
		if(zuoshang==2)
		{
			qian=0;
			hou =0;
			zuo=0;
			you =1;
		}
		if(youxia==2)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;

		}
		if(shizi==3)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
		}
		if(zuoT==1&&
			(shizi==3))
		{
			qian=0;
			car_set(0,0,0,0);
			ding=14;
		}
	}
	if(na==15)//到放置区（红色）
	{
		if(shizi==0)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==1)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==1)
		{
			
			qian=0;
			hou=0;
			zuo=1;
			you=0;
			piancha=piancha-400;
			piancha1=piancha1+300;
			buchang =1;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
			buchang=0;
		}
		if(youxia==2)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(xiaT==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==2)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}

		if(shizi==3)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(shizi==4)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youT==1)
		{
			hou=0;
			ding=15;
			car_set(0,0,0,0);
		}
	}
	if(na==16)//回存储区（红色）
	{
		if(shizi==0)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(youT==1)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(shizi==1)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(zuoshang ==1)
		{
			qian=0;
			hou=0;
			zuo =0;
			you=1;
			buchang=1;
		}
		if(youxia ==1)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
			buchang=0;
		}
		if(shizi==2)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(xiaT==1)
		{
			qian=0;
			hou=0;
			zuo =0;
			you=1;
		}
		if(youxia==2)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
			zuoT=0;
		}
		if(zuoshang==2)
		{
			qian=0;
			hou =0;
			zuo=0;
			you =1;
		}
		if(youxia==3)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;

		}
		if(shizi==3)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
		}
		if(zuoT==1&&
			(shizi==3))
		{
			qian=0;
			car_set(0,0,0,0);
			ding=16;
		}
	}
	
	if(na==17)//到放置区（红色）
	{
		if(shizi==0)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==1)
		{ 
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youxia==1)
		{
			
			qian=0;
			hou=0;
			zuo=1;
			you=0;
			piancha=piancha-400;
			piancha1=piancha1+300;
			buchang=1;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
			buchang=0;
		}
		if(youxia==2)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(xiaT==1)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(shizi==2)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}

		if(shizi==3)
		{
			qian=0;
			hou=0;
			zuo=1;
			you=0;
		}
		if(shizi==4)
		{
			qian=0;
			hou=1;
			zuo=0;
			you=0;
		}
		if(youT==1)
		{
			hou=0;
			ding=17;
			car_set(0,0,0,0);
		}
	}
	if(na==18)//回起点
	{
			if(shizi==0)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(shizi==1)
		{
			qian=0;
			hou=0;
			zuo =0;
			you=1;
		}
		if(shizi==2)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(shizi==3)
		{
			qian=1;
			hou=0;
			zuo =0;
			you=0;
		}
		if(xiaT==1)
		{
			qian=0;
			hou=0;
			zuo =0;
			you=1;
		}
		if(youxia==1)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;
			zuoT=0;
		}
		if(zuoshang==1)
		{
			qian=0;
			hou =0;
			zuo=0;
			you =1;

		}
		if(youxia==2)
		{
			qian=1;
			hou =0;
			zuo=0;
			you =0;

		}
		if(shizi==4)
		{
			qian=0;
			hou =0;
			zuo=1;
			you =0;
		}
		if(shizi==5)
		{
			qian=0;
			hou =0;
			zuo=1;
			you =0;
		}
		if(shizi==6)
		{
			qian=0;
			hou =1;
			zuo=0;
			you =0;
		}
		if(shangT==1)
		{
			hou=0;
			car_set(0,0,0,0);
			ding=18;
		}
	}
}
void MotorCtrl(void)
{
	if(na==0)
	{
		//发车
		if(qian ==0&&you ==0&&zuo==0&&hou==0) qian=1;

		//在前进过程中遇到第一个上T字；
		if(shangT==1)	qian=1;

	//遇到第一个十字后，继续直线循迹
		if(shizi==1)	qian=1;

		if(youT==1)
		{
			//此处应进行第一个物体颜色的判断，来进行路径规划；
			qian=0;
			ding=1;
		}
	}
	na_yellow_object_in_yellow_area();
	na_blue_object_in_blue_area();
	na_red_object_in_red_area();
//前进循迹
	if(qian ==1)
	{
		if(huidu[1]==1&&huidu[2]==1)	error=0;
		else if(huidu[1]==1&&huidu[2]==0&&huidu[0]==0)	error=-1;
		else if(huidu[0]==1&&huidu[1]==1)	error=-1.5;
		else if(huidu[0]==1&&huidu[1]==0)	error=-2;
		else if(huidu[2]==1&&huidu[1]==0&&huidu[3]==0)	error=1;
		else if(huidu[2]==1&&huidu[3]==1)	error =1.5;
		else if(huidu[2]==0&&huidu[3]==1)	error =2;
		piancha=kp*error+Integral_error*ki+(error-Last_error)*kd;
		Integral_error+=error;
		Last_error=error;
		car_set(speed+piancha,speed-piancha,speed+piancha,speed-piancha);
	}
		//后退循迹
	if(hou ==1)
	{
		if(huidu[13]==1&&huidu[14]==1)	error=0;
		else if(huidu[13]==1&&huidu[12]==0&&huidu[14]==0)	error=-1;
		else if(huidu[12]==1&&huidu[13]==1)	error=-1.5;
		else if(huidu[12]==1&&huidu[13]==0)	error=-2;
		else if(huidu[14]==1&&huidu[13]==0&&huidu[15]==0)	error=1;
		else if(huidu[14]==1&&huidu[15]==1)	error =1.5;
		else if(huidu[15]==0&&huidu[15]==1)	error =2;
		piancha=kp*error+Integral_error*ki+(error-Last_error)*kd;
		Integral_error+=error;
		Last_error=error;
		car_set(-speed-piancha,-speed+piancha,-speed-piancha,-speed+piancha);	
	}
	
//右走循迹
	
	if(you ==1)
	{
		if(huidu[9]==1&&huidu[10]==1)	error=0;
		else if(huidu[9]==1&&huidu[10]==0&&huidu[11]==0)	error=-1;
		else if(huidu[8]==1&&huidu[9]==1)	error=-1.5;
		else if(huidu[8]==1&&huidu[9]==0)	error=-2;
		else if(huidu[10]==1&&huidu[9]==0&&huidu[11]==0)	error=1;
		else if(huidu[10]==1&&huidu[11]==1)	error =1.5;
		else if(huidu[10]==0&&huidu[11]==1)	error =2;
		Integral_error+=error;
		piancha=kp1*error+Integral_error*ki1+(error-Last_error)*kd1;
		Last_error=error;
		
		if(huidu[5]==1&&huidu[6]==1)	error1=0;
		else if(huidu[5]==1&&huidu[4]==0&&huidu[6]==0)	error1=-1;
		else if(huidu[4]==1&&huidu[5]==1)	error1=-1.5;
		else if(huidu[4]==1&&huidu[5]==0)	error1=-2;
		else if(huidu[6]==1&&huidu[5]==0&&huidu[7]==0)	error1=1;
		else if(huidu[6]==1&&huidu[7]==1)	error1 =1.5;
		else if(huidu[7]==0&&huidu[6]==1)	error1=2;
		Integral_error1+=error1;
		piancha1=kp1*error1+Integral_error1*ki1+(error1-Last_error1)*kd1;
		Last_error1=error1;
			if(buchang==1&&fan1==0)
		{
			if(fan<=400)fan ++;
			if(fan>=400){fan=0;fan1=1;}
		}

		if(fan <150){
			b=200;
		}
		if(fan>=150)b=0;
		car_set(speed-piancha1-b,-speed-piancha,-speed-piancha1-b,speed-piancha);
	}
	

	//左走循迹
	if(zuo==1)
	{
		if(huidu[9]==1&&huidu[10]==1)	error=0;
		else if(huidu[9]==1&&huidu[10]==0&&huidu[11]==0)	error=-1;
		else if(huidu[8]==1&&huidu[9]==1)	error=-1.5;
		else if(huidu[8]==1&&huidu[9]==0)	error=-2;
		else if(huidu[10]==1&&huidu[9]==0&&huidu[11]==0)	error=1;
		else if(huidu[10]==1&&huidu[11]==1)	error =1.5;
		else if(huidu[10]==0&&huidu[11]==1)	error =2;
		Integral_error+=error;
		piancha=kp1*error+Integral_error*ki1+(error-Last_error)*kd1;
		Last_error=error;
		
		if(huidu[5]==1&&huidu[6]==1)	error1=0;
		else if(huidu[5]==1&&huidu[4]==0&&huidu[6]==0)	error1=-1;
		else if(huidu[4]==1&&huidu[5]==1)	error1=-1.5;
		else if(huidu[4]==1&&huidu[5]==0)	error1=-2;
		else if(huidu[6]==1&&huidu[5]==0&&huidu[7]==0)	error1=1;
		else if(huidu[6]==1&&huidu[7]==1)	error1 =1.5;
		else if(huidu[7]==0&&huidu[6]==1)	error1=2;
		Integral_error1+=error1;
		piancha1=kp1*error1+Integral_error1*ki1+(error1-Last_error1)*kd1;
		Last_error1=error1;
		if(buchang==1) b=70;
		if(buchang==0) b=0;
		car_set(-speed-piancha1,speed-piancha+b,speed-piancha1,-speed-piancha+b);
	}
}




void TIM3_Pwm_Init(u16 arr,u16 psc)
{  
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);	 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;   //对应CH3通道PB0
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	TIM_TimeBaseStructure.TIM_Period = arr;  
	TIM_TimeBaseStructure.TIM_Prescaler =psc; 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
	TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure); 

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;  
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
	TIM_OCInitStructure.TIM_Pulse=500; 
	
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);        
	TIM_OC3PreloadConfig(TIM3, TIM_OCPreload_Enable);

	TIM_OC4Init(TIM3, &TIM_OCInitStructure);        
	TIM_OC4PreloadConfig(TIM3, TIM_OCPreload_Enable); 

	TIM_Cmd(TIM3, ENABLE);  

}

void TIM4_Pwm_Init(u16 arr,u16 psc) 
{  
	
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);	 
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;   //对应CH3通道PB0
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;   
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure); 
	
	TIM_TimeBaseStructure.TIM_Period = arr;  
	TIM_TimeBaseStructure.TIM_Prescaler =psc; 
	TIM_TimeBaseStructure.TIM_ClockDivision = 0; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure); 

	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;  
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;  
	TIM_OCInitStructure.TIM_Pulse=500; 
	
	TIM_OC3Init(TIM4, &TIM_OCInitStructure);        
	TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);

	TIM_OC4Init(TIM4, &TIM_OCInitStructure);     
	TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable); 	


	TIM_Cmd(TIM4, ENABLE);  
}

float abs_float(float value) {
	if(value>0) {
		return value;
	}
	return (-value);
}

void duoji_inc_handle(u8 index) {	
	int aim_temp;
	
	if(duoji_doing[index].inc != 0) {
		
		aim_temp = duoji_doing[index].aim;
		
		if(aim_temp > 2490){
			aim_temp = 2490;
		} else if(aim_temp < 500) {
			aim_temp = 500;
		}
	
		if(abs_float(aim_temp - duoji_doing[index].cur) <= abs_float(duoji_doing[index].inc + duoji_doing[index].inc)) {
			duoji_doing[index].cur = aim_temp;
			duoji_doing[index].inc = 0;
		} else {
			duoji_doing[index].cur += duoji_doing[index].inc;
		}
	}
}

/***********************************************
	函数名称：	TIM2_IRQHandler() 
	功能介绍：	输出舵机控制波形
	函数参数：	无
	返回值：		无
 ***********************************************/
void TIM2_IRQHandler(void) {
	static u8 flag = 0;
	int temp;
	
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET) 					//检查 TIM2 更新中断发生与否
	{
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update ); 							//清除 TIM2 更新中断标志
		if(servo_data[servo_index].cur>2497)	servo_data[servo_index].cur=2497;
		if(servo_data[servo_index].cur<500)		servo_data[servo_index].cur=500;
		
		if(!flag) {
			if((servo_abs(servo_data[servo_index].aim-servo_data[servo_index].cur)>(servo_abs(servo_data[servo_index].inc)+10)))
			{
				servo_data[servo_index].cur=servo_data[servo_index].cur+servo_data[servo_index].inc;
			}
			else
			{
				servo_data[servo_index].cur=servo_data[servo_index].aim;
			}
			TIM2->ARR = ((unsigned int)(servo_data[servo_index].cur));
			servo_set(servo_index, 1);
		} else {
			temp = 20000 - (unsigned int)(servo_data[servo_index].cur);
			if(temp < 20)temp = 20;
			TIM2->ARR = temp;
			servo_set(servo_index, 0);
			servo_index ++;
		}
		if(servo_index >= SERVO_NUM) {
			servo_index = 0;
		}
		flag = !flag;
	}
} 



/***********************************************
	函数名称：timer1_ir_init(arr,psc) 
	功能介绍：初始化定时器1
	函数参数：arr：计数值 psc：分频值
	返回值：	无
 ***********************************************/
void timer1_ir_init(u16 arr,u16 psc)		
{
	TIM_ICInitTypeDef  TIM_ICInitStructure;
	TIM_TimeBaseInitTypeDef	TIM_TimeBaseInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA | RCC_APB2Periph_TIM1, ENABLE );

	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_IPU;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	NVIC_InitStructure.NVIC_IRQChannel        				= TIM1_CC_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority 	= 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority       	= 1;
	NVIC_InitStructure.NVIC_IRQChannelCmd               	= ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	NVIC_InitStructure.NVIC_IRQChannel        				= TIM1_UP_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority 	= 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority       	= 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd               	= ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	TIM_TimeBaseInitStructure.TIM_Period        = arr; 
	TIM_TimeBaseInitStructure.TIM_Prescaler     = psc; 
	TIM_TimeBaseInitStructure.TIM_ClockDivision = 0; 
	TIM_TimeBaseInitStructure.TIM_CounterMode   = TIM_CounterMode_Up;
	TIM_TimeBaseInit(TIM1, &TIM_TimeBaseInitStructure);

	TIM_ICInitStructure.TIM_Channel     = TIM_Channel_1;
	TIM_ICInitStructure.TIM_ICPolarity  = TIM_ICPolarity_Falling;
	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
	TIM_ICInitStructure.TIM_ICFilter    = 0x0;
	TIM_ICInit(TIM1, &TIM_ICInitStructure);
	
	TIM_ClearFlag(TIM1, TIM_FLAG_Update);
	TIM_ClearFlag(TIM1, TIM_FLAG_CC1);
	TIM_ITConfig(TIM1, TIM_IT_CC1,ENABLE);

	TIM_Cmd(TIM1, ENABLE);
}

