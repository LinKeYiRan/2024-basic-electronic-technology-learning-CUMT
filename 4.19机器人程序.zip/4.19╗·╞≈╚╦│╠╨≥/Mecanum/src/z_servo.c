#include "z_servo.h"

/***********************************************
0小于右 大于左
1小于前 大于后
2小于后 大于前
3大于后 小于前
 ***********************************************/

/*******全局变量定义*******/
u8 servo_done1=0;
u8 servo_done2=0;
u8 servo_done3=0;
servo_data_t servo_data[SERVO_NUM];
u8 servo_index;

/***********************************************
	函数名称：	servo_init() 
	功能介绍：	初始化舵机
	函数参数：	无
	返回值：		无
 ***********************************************/
void servo_init(void) {
	GPIO_InitTypeDef GPIO_InitStructure;	

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB | RCC_APB2Periph_AFIO, ENABLE);
	GPIO_PinRemapConfig(GPIO_Remap_SWJ_Disable, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin =  SERVO0_Pin|SERVO1_Pin|SERVO2_Pin|SERVO3_Pin|SERVO4_Pin|SERVO5_Pin;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(SERVO0_GPIO_Port, &GPIO_InitStructure);	
	servo_set(0,0);
	servo_set(1,0);
	servo_set(2,0);
	servo_set(3,0);
	servo_set(4,0);
	servo_set(5,0);
}

/***********************************************
	函数名称：	servo_set(index,level) 
	功能介绍：	设置舵机引脚输出量
	函数参数：	index 舵机编号 level 输出量
	返回值：		无
 ***********************************************/
void servo_set(u8 index, u8 level) {
	if(level) {
		switch(index) {
			case 0:	SERVO0_H();	break;
			case 1:	SERVO1_H();	break;
			case 2:	SERVO2_H();	break;
			case 3:	SERVO3_H();	break;
			case 4:	SERVO4_H();	break;
			case 5:	SERVO5_H();	break;
			default:	break;
		}
	}
	else {
		switch(index) {
			case 0:	SERVO0_L();	break;
			case 1:	SERVO1_L();	break;
			case 2:	SERVO2_L();	break;
			case 3:	SERVO3_L();	break;
			case 4:	SERVO4_L();	break;
			case 5:	SERVO5_L();	break;
			default:	break;
		}	
	}
}

/***********************************************
	函数名称：	servo_abs(value) 
	功能介绍：	绝对值计算
	函数参数：	value 转换量
	返回值：		转换量的绝对值
 ***********************************************/
float servo_abs(float value) {
	if(value>0) {
		return value;
	}
	return (-1*value);
}

/***********************************************
	函数名称：	servo_run(index,aim,time) 
	功能介绍：	舵机控制函数
	函数参数：	index 舵机编号 aim 目标值 time 时间量
	返回值：		无
 ***********************************************/
void servo_run(u8 index, int aim, int n) {

		servo_data[index].cur = servo_data[index].aim;
		servo_data[index].aim = aim;
		servo_data[index].inc = (aim-servo_data[index].cur)/n;
}

/***********************************************
	函数名称：	setup_servo() 
	功能介绍：	初始化舵机
	函数参数：	无
	返回值：		无
 ***********************************************/
void setup_servo(void) {
	begin_servointerrupt();
	servo_run(0,1500,1);
	servo_run(1,1700,1);
	servo_run(2,2000,1);
	servo_run(3,1900,1);
	servo_run(4,1500,1);
	servo_run(5,1500,1);
	servo_init();
	TIM2_init();
}
/***********************************************
	函数名称：	loop_servo() 
	功能介绍：	循环处理舵机的指令
	函数参数：	无
	返回值：		无
 ***********************************************/
void loop_servo(void) {
	if((servo_data[servo_index].cur!=servo_data[servo_index].aim)&&(servo_data[servo_index].time<=100))
	{
		if(servo_data[servo_index].flag)
		{
			servo_data[servo_index].cur=servo_data[servo_index].cur+servo_data[servo_index].inc;
			servo_data[servo_index].flag=0;
		}
		}
	else
		{
			servo_data[servo_index].cur=servo_data[servo_index].aim;
		}
}

/***********************************************
	函数名称：	actiongroup_near(void) 
	功能介绍：	抓取最近的那个快递
	函数参数：	无
	返回值：		完成返回1 否则为0
 ***********************************************/
int actiongroup_near(void)
{
	static u32 time_count=0;
	static u8 flag = 0;
	if(millis()-time_count > 1500)
	{
		time_count = millis();
		switch(flag)
		{
			case 0:
				servo_run(0,1000,8);
				servo_run(1,1250,8);
				servo_run(2,1800,8);
				servo_run(3,1600,8);
				break;
			case 1:
				servo_run(5,2500,1);
				servo_run(0,1000,8);
				servo_run(1,1150,8);
				servo_run(2,1900,8);
				servo_run(3,1500,8);
				break;
			case 2:
				servo_run(0,1500,8);
				servo_run(1,1700,8);
				servo_run(2,2000,8);
				servo_run(3,1900,8);
				break;
			case 3:
//				servo_run(5,500,1);
//				servo_run(4,2500,1);
				break;
		}
		flag++;
		if(flag>=4)
		{
			flag=0;
			servo_done1=1;
			return 1;
		}
	}
	return 0;
}

/***********************************************
	函数名称：	actiongroup_farleft(void) 
	功能介绍：	小车在左侧抓取较远的那个快递
	函数参数：	无
	返回值：		完成返回1 否则为0
 ***********************************************/
int actiongroup_farleft(void)
{
	static u32 time_count=0;
	static u8 flag = 0;
	if(millis()-time_count > 1500)
	{
		time_count = millis();
		switch(flag)
		{
			case 0:
				servo_run(0,1250,8);
				servo_run(1,1200,8);
				servo_run(2,1700,8);
				servo_run(3,1500,8);
				break;
			case 1:
				servo_run(5,2500,1);
				servo_run(0,1250,8);
				servo_run(1,1100,8);
				servo_run(2,1820,8);
				servo_run(3,1400,8);
				break;
			case 2:
				servo_run(0,1500,8);
				servo_run(1,1700,8);
				servo_run(2,2000,8);
				servo_run(3,1900,8);
				break;
			case 3:
//				servo_run(5,500,1);
//				servo_run(4,2500,1);
				break;
		}
		flag++;
		if(flag>=4)
		{
			flag=0;
			servo_done2=1;
			return 1;
		}
	}
	return 0;
}

/***********************************************
	函数名称：	actiongroup_farright(void) 
	功能介绍：	小车在右侧抓取较远的那个快递
	函数参数：	无
	返回值：		完成返回1 否则为0
 ***********************************************/
int actiongroup_farright(void)
{
	static u32 time_count=0;
	static u8 flag = 0;
	if(millis()-time_count > 1500)
	{
		time_count = millis();
		switch(flag)
		{
			case 0:
				servo_run(0,1760,8);
				servo_run(1,1200,8);
				servo_run(2,1700,8);
				servo_run(3,1500,8);
				break;
			case 1:
				servo_run(5,2500,1);
				servo_run(0,1750,8);
				servo_run(1,1100,8);
				servo_run(2,1820,8);
				servo_run(3,1400,8);
				break;
			case 2:
				servo_run(0,1500,8);
				servo_run(1,1750,8);
				servo_run(2,2000,8);
				servo_run(3,1900,8);
				break;
			case 3:
//				servo_run(5,500,1);
//				servo_run(4,2500,1);
				break;
		}
		flag++;
		if(flag>=4)
		{
			flag=0;
			servo_done3=1;
			return 1;
		}
	}
	return 0;
}

/***********************************************
	函数名称：	begin_servointerrupt() 
	功能介绍：	打开舵机中断，关掉串口三中断
	函数参数：	无
	返回值：		无
 ***********************************************/
void begin_servointerrupt(void) 
{
	USART_ITConfig(USART2, USART_IT_RXNE, DISABLE);
	TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE );  									//③允许更新中断
}

/***********************************************
	函数名称：	end_servointerrupt() 
	功能介绍：	关闭舵机中断，打开串口三中断
	函数参数：	无
	返回值：		无
 ***********************************************/
void end_servointerrupt(void) 
{
	USART_ITConfig(USART2, USART_IT_RXNE, ENABLE);
	TIM_ITConfig(TIM2,TIM_IT_Update,DISABLE );  									//③允许更新中断
}
