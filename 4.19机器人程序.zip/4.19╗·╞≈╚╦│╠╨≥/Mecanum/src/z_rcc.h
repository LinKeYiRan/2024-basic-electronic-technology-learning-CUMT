#ifndef __TB_RCC_H__
#define __TB_RCC_H__


void tb_rcc_init(void);


#endif


